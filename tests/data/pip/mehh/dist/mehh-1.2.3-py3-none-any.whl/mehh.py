def mehh():
    print("mehh")
